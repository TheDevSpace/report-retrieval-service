package kz.eub.statementservice.model.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import kz.eub.statementservice.model.entity.Statement;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name = "sbns_kz_statement_operations")
public class StatementOperation {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    @Column(name = "benef_name")
    private String benefName;
    @Column(name = "doc_number")
    private String docNumber;
    @Column(name = "payer_name")
    private String payer_name;
    @Column(name = "benef_account_curr_iso_code")
    private String benef_account_curr_iso_code;
    @Column(name = "payer_account_curr_iso_code")
    private String payer_account_curr_iso_code;
    @Column(name = "credit")
    private BigDecimal credit;
    @Column(name = "debet")
    private BigDecimal debet;
    @Column(name = "payment_purpose")
    private String payment_purpose;

    @Column(name = "syscreatetime")
    @JsonFormat
            (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDateTime sysCreateTime;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "statement_id")
    private Statement statementId;



}
