package kz.eub.statementservice.repository;

import kz.eub.statementservice.model.entity.Statement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StatementRepository extends JpaRepository<Statement, String> {

//    @Query(value = "SELECT\n" +
//            "       (SELECT s.outboundbalance\n" +
//            "        FROM sbns_kz_statement s\n" +
//            "        WHERE s.account = 'KZ5594802KZT22030238'\n" +
//            "        ORDER BY s.fromdate DESC\n" +
//            "        LIMIT 1) AS LatestOutbalBalance,\n" +
//            "       (SELECT s.inboundbalance\n" +
//            "        FROM sbns_kz_statement s\n" +
//            "        WHERE s.account = 'KZ5594802KZT22030238'\n" +
//            "        ORDER BY s.fromdate ASC\n" +
//            "        LIMIT 1) AS EarliestInbalBalance,\n" +
//            "       (SELECT SUM(credit)\n" +
//            "        FROM sbns_kz_statement_operations\n" +
//            "        WHERE statement_id IN (SELECT id FROM sbns_kz_statement\n" +
//            "                               WHERE account = 'KZ5594802KZT22030238'\n" +
//            "                                 AND fromdate BETWEEN '2023-12-28' AND '2023-12-31')) AS sumCredit,\n" +
//            "       (SELECT SUM(debet)\n" +
//            "        FROM sbns_kz_statement_operations\n" +
//            "        WHERE statement_id IN (SELECT id FROM sbns_kz_statement\n" +
//            "                               WHERE account = 'KZ5594802KZT22030238'\n" +
//            "                                 AND fromdate BETWEEN '2023-12-28' AND '2023-12-31')) AS sumDebit\n" +
//            "FROM sbns_kz_statement_operations skso\n" +
//            "WHERE skso.statement_id IN (SELECT sks.id FROM sbns_kz_statement sks\n" +
//            "                            WHERE sks.account = 'KZ5594802KZT22030238'\n" +
//            "                              AND sks.fromdate BETWEEN '2023-12-28' AND '2023-12-31');", nativeQuery = true)
//    StatementProjection getStatementOperationDtoByIdV2(@Param("fromDate") LocalDate fromDate,
//                                                       @Param("toDate") LocalDate toDate,
//                                                       @Param("account") String account);

}
