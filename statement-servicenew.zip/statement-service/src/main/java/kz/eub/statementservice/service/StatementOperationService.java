package kz.eub.statementservice.service;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.itextpdf.text.pdf.draw.DottedLineSeparator;
import com.itextpdf.text.pdf.draw.VerticalPositionMark;
import jakarta.persistence.Table;
import kz.eub.statementservice.model.dto.OperationDetailsDto;
import kz.eub.statementservice.model.dto.OperationDetailsProjection;
import kz.eub.statementservice.model.dto.StatementOperationResp;
import kz.eub.statementservice.model.entity.StatementOperation;
import kz.eub.statementservice.model.StatementProjection;
import kz.eub.statementservice.model.dto.StatementResponse;
import kz.eub.statementservice.repository.StatementOperationRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class StatementOperationService {

    private final StatementOperationRepository repository;

    public StatementOperationService(StatementOperationRepository repository) {
        this.repository = repository;
    }


    public StatementResponse getSt(String account, LocalDate fromDate, LocalDate toDate, Pageable pageable, String operationType2, BigDecimal fromSum, BigDecimal toSum, String search) {
        StatementProjection statementProjection = repository.getStatementOperationDtoByIdV2(fromDate, toDate, account, operationType2);

        Specification<StatementOperation> spec = StatementSpecification.findByStatementCriteria(account, fromDate, toDate, operationType2, fromSum, toSum, search);

        Page<StatementOperation> pageData = repository.findAll(spec, pageable);

        List<StatementOperationResp> statementResponse =pageData.getContent().stream()
                .map(statementOperation -> {
                    String receiver;
                    BigDecimal sum;
                    String currencyCode;
                    String operationType;
                    if (statementOperation.getBenefName() != null && !statementOperation.getBenefName().isEmpty()) {
                        receiver = statementOperation.getBenefName();
                    } else {
                        receiver = statementOperation.getPayer_name();
                    }
                    if (statementOperation.getCredit() != null) {
                        sum = statementOperation.getCredit();
                        operationType = "credit";
                    } else {
                        sum = statementOperation.getDebet();
                        operationType = "debit";
                    }
                    if (statementOperation.getBenef_account_curr_iso_code() != null) {
                        currencyCode = statementOperation.getBenef_account_curr_iso_code();
                    } else {
                        currencyCode = statementOperation.getPayer_account_curr_iso_code();
                    }
                    return new StatementOperationResp(
                            statementOperation.getId(),
                            statementOperation.getDocNumber(),
                            receiver,
                            currencyCode,
                            sum,
                            statementOperation.getPayment_purpose(),
                            account,
                            operationType
                    );
                })
                .collect(Collectors.toList());

        return new StatementResponse(
                statementProjection.getOutboundBalance(),
                statementProjection.getInBoundBalance(),
                statementProjection.getSumCredit(),
                statementProjection.getSumDebit(),
                statementResponse);

    }

    public OperationDetailsDto getOperationDetails(String operationId) {
        OperationDetailsProjection operationDetailsProjection = repository.getStatementOperationDetails(operationId);
        OperationDetailsDto operationDetailsDto = new OperationDetailsDto();
        operationDetailsDto.setId(operationDetailsProjection.getId());
        operationDetailsDto.setAccount(operationDetailsProjection.getAccount());
        operationDetailsDto.setBic(operationDetailsProjection.getBic());
        operationDetailsDto.setBankname(operationDetailsProjection.getBankname());
        operationDetailsDto.setInn(operationDetailsProjection.getInn());
        operationDetailsDto.setKbe(operationDetailsProjection.getKbe());
        operationDetailsDto.setDoc_number(operationDetailsProjection.getDoc_number());

        return operationDetailsDto;
    }


    private BaseFont defaultFont = null;
    private BaseFont boldFont = null;
    private BaseFont checkBoxFont = null;
    public byte[] createPdf(String dto) {
        Chunk space = new Chunk(" ");
        space.setHorizontalScaling(20F);
        ByteArrayOutputStream baos = null;
        Document document = null;
        try {
            document = new Document(PageSize.A4.rotate());
//            FileOutputStream baos = new FileOutputStream("src/main/resources/pdfTest.pdf");
            baos = new ByteArrayOutputStream();
            PdfWriter.getInstance(document, baos);
            document.open();

            Paragraph applicationText = new Paragraph("Поступило в банк-получатель", getFont(Font.BOLD));
            applicationText.setAlignment(Element.ALIGN_LEFT);
            document.add(applicationText);

            Chunk header = new Chunk("ПЛАТЕЖНОЕ ПОРУЧЕНИЕ № ", getFont(Font.BOLD));
            Chunk header2 = new Chunk(dto, getFont(Font.BOLD));
            Paragraph clientAddressParagraph1 = new Paragraph();
            clientAddressParagraph1.setAlignment(Element.ALIGN_CENTER);
            clientAddressParagraph1.add(header);
            clientAddressParagraph1.add(header2);
            document.add(clientAddressParagraph1);

            LocalDate date =LocalDate.now();
            Paragraph docDate = new Paragraph(String.format(date.toString()), getFont(Font.NORMAL));
            docDate.setAlignment(Element.ALIGN_CENTER);
            document.add(docDate);


            Chunk docDateNote = new Chunk("(дата документа)", getFont(Font.NORMAL));
            Paragraph docDateParagraph = new Paragraph();
            docDateParagraph.setAlignment(Element.ALIGN_CENTER);
            docDateParagraph.add(docDateNote);
            document.add(docDateParagraph);

            addNewLine(document);

            PdfPTable table1 = new PdfPTable(5);
            table1.getDefaultCell().setBorderWidth(1.5f); // Устанавливаем толщину границы
            table1.setWidthPercentage(100);
            table1.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            // 1 строка 1 столбец
            PdfPCell cell1_1 = new PdfPCell(new Phrase("Отправитель денег", getFont(Font.NORMAL)));
            cell1_1.setMinimumHeight(30f); // Установка минимальной высоты ячейки
            cell1_1.setHorizontalAlignment(Element.ALIGN_CENTER); // Выравнивание содержимого по центру
            table1.addCell(cell1_1);
            // 1 строка 2 столбец
            PdfPCell cell1_2 = new PdfPCell(new Phrase("TOO Partner", getFont(Font.NORMAL)));
            table1.addCell(cell1_2);
            // 1 и 2 строка объединяем из 3 столбец
            PdfPCell cell1_3 = new PdfPCell(new Phrase("КОд", getFont(Font.NORMAL)));
            cell1_3.setRowspan(2); // Объединение на 2 строки
            table1.addCell(cell1_3);
            // 1 и 2 строка объединяем из 4 столбец
            PdfPCell cell1_4 = new PdfPCell(new Phrase("ИИК", getFont(Font.NORMAL)));
            cell1_4.setRowspan(2); // Объединение на 2 строки
            table1.addCell(cell1_4);
            // 1 и 2 строка объединяем из 5 столбец
            PdfPCell cell1_5 = new PdfPCell(new Phrase("СУММА", getFont(Font.NORMAL)));
            cell1_5.setRowspan(6); // Объединение на 3 строки
            table1.addCell(cell1_5);

            // 2 строка 1 столбец
            PdfPCell cell2_1 = new PdfPCell(new Phrase("ИИН (БИН)", getFont(Font.NORMAL)));
            cell2_1.setMinimumHeight(30f); // Установка минимальной высоты ячейки
            table1.addCell(cell2_1);
            // 2 строка 2 столбец
            PdfPCell cell2_2 = new PdfPCell(new Phrase("1234324534", getFont(Font.NORMAL)));
            table1.addCell(cell2_2);

            // 3 строка 1 столбец
            PdfPCell cell3_11 = new PdfPCell(new Phrase("Банк отправителя", getFont(Font.NORMAL)));
            cell3_11.setMinimumHeight(30f); // Установка минимальной высоты ячейки
            table1.addCell(cell3_11);
            // 1 строка 2 столбец
            PdfPCell cell3_21 = new PdfPCell(new Phrase("bank otpr", getFont(Font.NORMAL)));
            table1.addCell(cell3_21);
            // 1 и 2 строка объединяем из 3 столбец
            PdfPCell cell3_3 = new PdfPCell(new Phrase("БИК", getFont(Font.NORMAL)));
            cell3_3.setColspan(2);
            table1.addCell(cell3_3);

            // 3 строка 1 столбец
            PdfPCell cell4_1 = new PdfPCell(new Phrase("Бенефициар", getFont(Font.NORMAL)));
            cell4_1.setMinimumHeight(30f); // Установка минимальной высоты ячейки
            table1.addCell(cell4_1);
            // 1 строка 2 столбец
            PdfPCell cell4_2 = new PdfPCell(new Phrase("benef name", getFont(Font.NORMAL)));
            table1.addCell(cell4_2);
            // 1 и 2 строка объединяем из 3 столбец
            PdfPCell cell4_3 = new PdfPCell(new Phrase("КБе", getFont(Font.NORMAL)));
            cell4_3.setRowspan(2); // Объединение на 2 строки
            table1.addCell(cell4_3);
            // 1 и 2 строка объединяем из 4 столбец
            PdfPCell cell4_4 = new PdfPCell(new Phrase("ИИК", getFont(Font.NORMAL)));
            cell4_4.setRowspan(2); // Объединение на 2 строки
            table1.addCell(cell1_4);

            PdfPCell cell5_1 = new PdfPCell(new Phrase("ИИН (БИН)", getFont(Font.NORMAL)));
            cell5_1.setMinimumHeight(30f); // Установка минимальной высоты ячейки
            table1.addCell(cell5_1);
            PdfPCell cell5_2 = new PdfPCell(new Phrase("1234324534_2", getFont(Font.NORMAL)));
            table1.addCell(cell5_2);

            PdfPCell cell6_1 = new PdfPCell(new Phrase("Банк бенефициара", getFont(Font.NORMAL)));
            cell6_1.setMinimumHeight(30f); // Установка минимальной высоты ячейки
            table1.addCell(cell6_1);
            PdfPCell cell6_2 = new PdfPCell(new Phrase("bank benef", getFont(Font.NORMAL)));
            table1.addCell(cell6_2);
            PdfPCell cell6_3 = new PdfPCell(new Phrase("БИК", getFont(Font.NORMAL)));
            cell6_3.setColspan(2);
            table1.addCell(cell6_3);

            PdfPCell cell7_1 = new PdfPCell(new Phrase("Сумма прописью", getFont(Font.NORMAL)));
            cell7_1.setMinimumHeight(30f); // Установка минимальной высоты ячейки
            table1.addCell(cell7_1);
            // 1 строка 2 столбец
            PdfPCell cell7_2 = new PdfPCell(new Phrase("Шестьсот тысяч тенге 00 тиын", getFont(Font.NORMAL)));
            cell7_2.setColspan(4);
            table1.addCell(cell7_2);

            // 3 строка 1 столбец
            PdfPCell cell8_1 = new PdfPCell(new Phrase("Дата получения товара (оказания услуг)", getFont(Font.NORMAL)));
            cell8_1.setMinimumHeight(30f); // Установка минимальной высоты ячейки
            cell8_1.setColspan(2);
            table1.addCell(cell8_1);
            // 1 строка 2 столбец
            PdfPCell cell8_2 = new PdfPCell(new Phrase("???", getFont(Font.NORMAL)));
            table1.addCell(cell8_2);
            // 1 строка 2 столбец
            PdfPCell cell8_3 = new PdfPCell(new Phrase("Код назначения\n" +
                    "платежа\n", getFont(Font.NORMAL)));
            table1.addCell(cell8_3);
            // 1 строка 2 столбец
            PdfPCell cell8_4 = new PdfPCell(new Phrase("knp 833", getFont(Font.NORMAL)));
            table1.addCell(cell8_4);

            PdfPCell cell9_1 = new PdfPCell(new Phrase("Назначение платежа\n" +
                    "(с указанием наименования товара, выполненных работ, оказанных услуг, номеров и даты товарных документов,\n" +
                    "номера и даты договора и иных реквизитов)", getFont(Font.NORMAL)));
            cell9_1.setRowspan(2); // Объединение на 3 строки
            cell9_1.setColspan(3);
            cell9_1.setMinimumHeight(30f); // Установка минимальной высоты ячейки
            table1.addCell(cell9_1);
            // 1 строка 2 столбец
            PdfPCell cell9_4 = new PdfPCell(new Phrase("Код бюджетной\n" +
                    "классификации", getFont(Font.NORMAL)));
            table1.addCell(cell9_4);
            PdfPCell cell9_5 = new PdfPCell(new Phrase("????", getFont(Font.NORMAL)));
            table1.addCell(cell9_5);

            PdfPCell cell10_1 = new PdfPCell(new Phrase("Дата валютирования", getFont(Font.NORMAL)));

            table1.addCell(cell10_1);
            LocalDate date1 =LocalDate.now();
            PdfPCell cell10_2 = new PdfPCell(new Phrase(date1.toString()));
            table1.addCell(cell10_2);

            PdfPCell cell11_1 = new PdfPCell(new Phrase("В том числе НДС", getFont(Font.NORMAL)));
            table1.addCell(cell11_1);
            PdfPCell cell11_2 = new PdfPCell(new Phrase("????", getFont(Font.NORMAL)));
            cell11_2.setColspan(4);
            table1.addCell(cell11_2);
            PdfPCell cell11_3 = new PdfPCell(new Phrase(""));
            table1.addCell(cell11_3);
            PdfPCell cell11_4 = new PdfPCell(new Phrase(""));
            table1.addCell(cell11_4);
            PdfPCell cell11_5 = new PdfPCell(new Phrase(""));
            table1.addCell(cell11_5);

            document.add(table1);
            addNewLine(document);

            Chunk glue = new Chunk(new VerticalPositionMark());
            Chunk fio = new Chunk("        Руководитель                 ", getFont(Font.NORMAL));
            Chunk fioInput = new Chunk("Usupov Р М", getFont(Font.UNDERLINE));
            Chunk text1 = new Chunk("Проведено банком-получателем     ", getFont(Font.NORMAL));
            Paragraph fioParagraph = new Paragraph();
            fioParagraph.add(fio);
            fioParagraph.add(fioInput);
           fioParagraph.add(new Chunk(glue));
            fioParagraph.add(text1);
            document.add(fioParagraph);

            Paragraph mp = new Paragraph("М.П.", getFont(Font.NORMAL));
            mp.add(new Chunk(glue));
            Chunk mp3 = new Chunk("\"    \"                                              20    г.", getFont(Font.UNDERLINE));
            Chunk mp2 = new Chunk("                                                                ", getFont(Font.UNDERLINE));
            mp.add(mp3);
            document.add(mp);

            Chunk position = new Chunk("        Главный бухгалтер          ", getFont(Font.NORMAL));
            Chunk positionInput = new Chunk("Kairkenova К К", getFont(Font.UNDERLINE));
            Paragraph positionParagraph = new Paragraph();
            positionParagraph.add(position);
            positionParagraph.add(positionInput);
            positionParagraph.add(new Chunk(glue));
            positionParagraph.add(mp2);
            document.add(positionParagraph);

            Paragraph line = new Paragraph(mp2);
            line.setAlignment(Element.ALIGN_RIGHT);
            document.add(line);

            Paragraph line1 = new Paragraph("(Подписи ответисполнителей)     ", getFont(Font.NORMAL));
            line1.setAlignment(Element.ALIGN_RIGHT);
            document.add(line1);

            document.close();
        } catch (DocumentException | IOException ex) {
            log.error(ex.getMessage(), ex);
            throw new RuntimeException(ex.getMessage(), ex);
        } finally {
            document.close();
            try {
                baos.close();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return baos.toByteArray();
    }

    private Font getFont(Integer font) throws DocumentException, IOException {
        if (defaultFont == null)
//            defaultFont = BaseFont.createFont("/tmp/times-font/times.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
            defaultFont = BaseFont.createFont("C:\\Users\\user\\IdeaProjects\\statement-service\\src\\main\\resources\\kztimesnewroman.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
        if (boldFont == null)
//            boldFont = BaseFont.createFont("/tmp/times-font/timesbd.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
            boldFont = BaseFont.createFont("C:\\Users\\user\\IdeaProjects\\statement-service\\src\\main\\resources\\timesbd.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
        switch (font) {
            case 0:
                return new Font(defaultFont, 11, Font.NORMAL);
            case 1:
                return new Font(boldFont, 11, Font.NORMAL);
            case 2:
                return new Font(defaultFont, 11, Font.ITALIC);
            case 4:
                return new Font(defaultFont, 11, Font.UNDERLINE);
            default:
                throw new RuntimeException("Font not found");
        }
    }

    private void addNewLine(Document doc) throws DocumentException {
        Paragraph empty = new Paragraph("\n");
        doc.add(empty);
    }
}
