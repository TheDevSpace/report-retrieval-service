package kz.eub.statementservice.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

public interface OperationDetailsProjection {

   UUID getId();
   String getAccount();
   String getBic();
   String getBankname();
   String getInn();
   String getKbe();
   String getDoc_number();
   String getDocDate();
   String getValueDate();
   String getNds();
   String getPayer_Name();
   String getPayer_Inn();
   String getPayer_Bank_Name();
   String getPayer_Bank_Bic();
   String getPayerOrgType();
   String getPayerAccount();
   String getBenefAccount();
   String getBenef_Name();
   String getBenef_Inn();
   String getBenef_Bank_Name();
   String getBenef_Bank_Bic();
   String getBenef_Org_Type();
   String getPayment_Purpose();
   String getPay_Purpose_Code();
   String getExecutive();
   String getChiefAccountant();
   BigDecimal getDebet();
   BigDecimal getCredit();

}

