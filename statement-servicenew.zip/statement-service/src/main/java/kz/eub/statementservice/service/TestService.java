//package kz.eub.statementservice.service;
//
//import com.itextpdf.kernel.colors.Color;
//import com.itextpdf.kernel.colors.DeviceRgb;
//import com.itextpdf.kernel.font.PdfFont;
//import com.itextpdf.kernel.font.PdfFontFactory;
//import com.itextpdf.kernel.pdf.PdfDocument;
//import com.itextpdf.layout.element.Cell;
//import com.itextpdf.layout.element.Paragraph;
//import com.itextpdf.layout.element.Table;
//import com.itextpdf.layout.properties.TextAlignment;
//import com.itextpdf.text.Chunk;
//import com.itextpdf.text.Document;
//import com.itextpdf.text.DocumentException;
//import com.itextpdf.text.PageSize;
//import com.itextpdf.text.pdf.PdfWriter;
//import org.springframework.stereotype.Service;
//
//import java.io.ByteArrayOutputStream;
//import java.io.IOException;
//
//@Service
//public class TestService {
//
//    public byte[] testPdf() {
//        Chunk space = new Chunk(" ");
//        space.setHorizontalScaling(20F);
//        ByteArrayOutputStream baos = null;
//        com.itextpdf.text.Document document = null;
//        try {
//
//            document = new Document(PageSize.A4.rotate());
//            baos = new ByteArrayOutputStream();
//            PdfWriter.getInstance(document, baos);
//            document.open();
//
//            // Создание шрифта
//            PdfFont font = PdfFontFactory.createFont();
//
//            // Создание таблицы
//            Table table = new Table(new float[]{3, 1, 1, 1}); // 4 столбца
//            Color backgroundColor = new DeviceRgb(204, 204, 204); // Серый цвет в формате RGB
//
//            // Заполнение таблицы
//            table.addCell(new Cell(1, 4)
//                    .add(new Paragraph("Заголовок таблицы")
//                            .setFont(font)
//                            .setBold())
//                    .setBackgroundColor(backgroundColor)
//                    .setTextAlignment(TextAlignment.CENTER));
//
//            table.addCell(new Cell()
//                    .add(new Paragraph("Строка 1")));
//
//            table.addCell(new Cell()
//                    .add(new Paragraph("Строка 2")));
//
//            table.addCell(new Cell()
//                    .add(new Paragraph("Строка 3")));
//
//            // Создание PDF
//            document.add(table);
//        } catch (IOException e) {
//            e.printStackTrace();
//        } catch (DocumentException e) {
//            throw new RuntimeException(e);
//        }
//
//        return baos.toByteArray();
//    }
//}
//
