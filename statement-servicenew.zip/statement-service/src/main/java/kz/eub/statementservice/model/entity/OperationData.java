package kz.eub.statementservice.model.entity;

public class OperationData {


}
