package kz.eub.statementservice.repository;

import kz.eub.statementservice.model.dto.OperationDetailsProjection;
import kz.eub.statementservice.model.entity.StatementOperation;
import kz.eub.statementservice.model.StatementProjection;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;


@Repository
public interface StatementOperationRepository extends JpaRepository<StatementOperation, UUID>, JpaSpecificationExecutor<StatementOperation> {

    List<StatementOperation> findAll(Specification<StatementOperation> specification);


    @Query(value = "SELECT\n" +
            "(SELECT s.outboundbalance\n" +
            "FROM sbns_kz_statement s\n" +
            "WHERE s.account = :account\n" +
            "ORDER BY s.fromdate DESC\n" +
            "LIMIT 1) AS outboundBalance,\n" +
            "(SELECT s.inboundbalance\n" +
            "FROM sbns_kz_statement s\n" +
            "WHERE s.account = :account\n" +
            "ORDER BY s.fromdate ASC\n" +
            "LIMIT 1) AS inBoundBalance,\n" +
            "CASE\n" +
            "  WHEN :operationType = 'credit' THEN\n" +
            "      0\n" +
            "  ELSE\n" +
            "      (SELECT SUM(credit)\n" +
            "       FROM sbns_kz_statement_operations\n" +
            "       WHERE statement_id IN (SELECT id FROM sbns_kz_statement f\n" +
            "                              WHERE f.account = :account\n" +
            "                                 and f.fromDate BETWEEN :fromDate AND :toDate))\n" +
            "  END AS sumCredit,\n" +
            "CASE\n" +
            "  WHEN :operationType = 'debit' THEN\n" +
            "      0\n" +
            "  ELSE\n" +
            "      (SELECT SUM(debet)\n" +
            "       FROM sbns_kz_statement_operations\n" +
            "       WHERE statement_id IN (SELECT id FROM sbns_kz_statement f\n" +
            "                              WHERE f.account = :account\n" +
            "                             and f.fromDate BETWEEN :fromDate AND :toDate))\n" +
            "  END AS sumDebit", nativeQuery = true)
    StatementProjection getStatementOperationDtoByIdV2(@Param("fromDate") LocalDate fromDate,
                                                       @Param("toDate") LocalDate toDate,
                                                       @Param("account") String account,
                                                       @Param("operationType") String operationType);


    @Query(value = "SELECT skso.id,\n" +
            "    CASE\n" +
            "        WHEN skso.credit IS NOT NULL THEN skso.payeraccount\n" +
            "        ELSE skso.benefaccount\n" +
            "        END AS account,\n" +
            "    CASE\n" +
            "        WHEN skso.credit IS NOT NULL THEN skso.payer_bank_bic\n" +
            "        ELSE skso.benef_bank_bic\n" +
            "        END AS bic,\n" +
            "    CASE\n" +
            "        WHEN skso.credit IS NOT NULL THEN skso.payer_bank_name\n" +
            "        ELSE skso.benef_bank_name\n" +
            "        END AS bankname,\n" +
            "    CASE\n" +
            "        WHEN skso.credit IS NOT NULL THEN skso.payer_inn\n" +
            "        ELSE skso.benef_inn\n" +
            "        END AS inn,\n" +
            "    CASE\n" +
            "        WHEN skso.credit IS NOT NULL THEN skso.payerorgtype\n" +
            "        ELSE skso.benef_org_type\n" +
            "        END AS kbe,\n" +
            "    skso.doc_number,\n" +
            "    skso.docdate, skso.valuedate, skso.nds,\n" +
            "    skso.payer_name, skso.payer_inn, skso.payer_bank_name, skso.payer_bank_bic,skso.payerorgtype, skso.payeraccount,\n" +
            "    skso.benef_name, skso.benef_inn, skso.benef_bank_name, skso.benef_bank_bic, skso.benef_org_type,skso.payment_purpose, skso.benefaccount,\n" +
            "    skso.pay_purpose_code, skso.executive, skso.chiefaccountant, skso.debet, skso.credit\n" +
            "FROM\n" +
            "    sbns_kz_statement_operations skso\n" +
            "WHERE skso.id = '018d538f-b894-1ac4-bf91-b87ad217173e'", nativeQuery = true)
    OperationDetailsProjection getStatementOperationDetails(@Param("operation_id") String operationId);



    @Query(value = "select sb.docdate, sb.valuedate, sb.nds, sb.docnumber,\n" +
            "       sb.payername, sb.payerinn, sb.payerbankname, sb.payerbankbic,sb.payerorgtype, sb.payeraccount,\n" +
            "       sb.benefname, sb.benefinn, sb.benefbankname, sb.benefbankbic, sb.beneforgtype,sb.paymentpurpose, sb.payeraccount,\n" +
            "       sb.paypurposecode, sb.executive, sb.chiefaccountant\n" +
            "from sbns_kz_statement_operations sb\n" +
            "where sb.id = :operationId", nativeQuery = true)
    OperationDetailsProjection getStatementOperationData(@Param("operationId") String operationId);
}