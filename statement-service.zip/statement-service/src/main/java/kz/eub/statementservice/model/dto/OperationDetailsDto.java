package kz.eub.statementservice.model.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.UUID;

@Data
@RequiredArgsConstructor
public class OperationDetailsDto {
   private UUID id;
   private String account;
   private String bic;
   private String bankname;
   private String inn;
   private String kbe;
   private String doc_number;
}
