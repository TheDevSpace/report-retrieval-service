package kz.eub.statementservice.service;

import kz.eub.statementservice.model.dto.OperationDetailsDto;
import kz.eub.statementservice.model.dto.OperationDetailsProjection;
import kz.eub.statementservice.model.dto.StatementOperationResp;
import kz.eub.statementservice.model.entity.StatementOperation;
import kz.eub.statementservice.model.StatementProjection;
import kz.eub.statementservice.model.dto.StatementResponse;
import kz.eub.statementservice.repository.StatementOperationRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class StatementOperationService {

    private final StatementOperationRepository repository;

    public StatementOperationService(StatementOperationRepository repository) {
        this.repository = repository;
    }


    public StatementResponse getSt(String account, LocalDate fromDate, LocalDate toDate, Pageable pageable, String operationType2, BigDecimal fromSum, BigDecimal toSum, String search) {
        StatementProjection statementProjection = repository.getStatementOperationDtoByIdV2(fromDate, toDate, account, operationType2);

        Specification<StatementOperation> spec = StatementSpecification.findByStatementCriteria(account, fromDate, toDate, operationType2, fromSum, toSum, search);

        Page<StatementOperation> pageData = repository.findAll(spec, pageable);

        List<StatementOperationResp> statementResponse =pageData.getContent().stream()
                .map(statementOperation -> {
                    String receiver;
                    BigDecimal sum;
                    String currencyCode;
                    String operationType;
                    if (statementOperation.getBenefName() != null && !statementOperation.getBenefName().isEmpty()) {
                        receiver = statementOperation.getBenefName();
                    } else {
                        receiver = statementOperation.getPayer_name();
                    }
                    if (statementOperation.getCredit() != null) {
                        sum = statementOperation.getCredit();
                        operationType = "credit";
                    } else {
                        sum = statementOperation.getDebet();
                        operationType = "debit";
                    }
                    if (statementOperation.getBenef_account_curr_iso_code() != null) {
                        currencyCode = statementOperation.getBenef_account_curr_iso_code();
                    } else {
                        currencyCode = statementOperation.getPayer_account_curr_iso_code();
                    }
                    return new StatementOperationResp(
                            statementOperation.getId(),
                            statementOperation.getDocNumber(),
                            receiver,
                            currencyCode,
                            sum,
                            statementOperation.getPayment_purpose(),
                            account,
                            operationType
                    );
                })
                .collect(Collectors.toList());

        return new StatementResponse(
                statementProjection.getOutboundBalance(),
                statementProjection.getInBoundBalance(),
                statementProjection.getSumCredit(),
                statementProjection.getSumDebit(),
                statementResponse);

    }

    public OperationDetailsDto getOperationDetails(String operationId) {

        OperationDetailsProjection operationDetailsProjection = repository.getStatementOperationDetails(operationId);
        OperationDetailsDto operationDetailsDto = new OperationDetailsDto();
        operationDetailsDto.setId(operationDetailsProjection.getId());
        operationDetailsDto.setAccount(operationDetailsProjection.getAccount());
        operationDetailsDto.setBic(operationDetailsProjection.getBic());
        operationDetailsDto.setBankname(operationDetailsProjection.getBankname());
        operationDetailsDto.setInn(operationDetailsProjection.getInn());
        operationDetailsDto.setKbe(operationDetailsProjection.getKbe());
        operationDetailsDto.setDoc_number(operationDetailsProjection.getDoc_number());


        return operationDetailsDto;
    }
}
