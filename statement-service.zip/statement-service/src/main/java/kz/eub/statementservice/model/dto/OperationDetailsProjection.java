package kz.eub.statementservice.model.dto;

import java.util.UUID;

public interface OperationDetailsProjection {

   UUID getId();
   String getAccount();
   String getBic();
   String getBankname();
   String getInn();
   String getKbe();
   String getDoc_number();


}

