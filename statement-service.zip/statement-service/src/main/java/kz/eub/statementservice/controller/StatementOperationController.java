package kz.eub.statementservice.controller;

import kz.eub.statementservice.model.dto.OperationDetailsDto;
import kz.eub.statementservice.model.dto.OperationDetailsProjection;
import kz.eub.statementservice.model.dto.StatementResponse;
import kz.eub.statementservice.service.StatementOperationService;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@RestController
@RequestMapping("/api/operations")
public class StatementOperationController {
    private final StatementOperationService statementOperationService;

    public StatementOperationController(StatementOperationService statementOperationService) {
        this.statementOperationService = statementOperationService;
    }

    @GetMapping(value = "/test", produces = "application/json;charset=UTF-8")
    public StatementResponse pushNotificationsByList(@RequestParam(value = "account") String account,
                                                     @RequestParam(value = "from-date", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateFrom,
                                                     @RequestParam(value = "to-date", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateTo,
                                                     @RequestParam(name = "page", defaultValue = "0") int page,
                                                     @RequestParam(name = "size", defaultValue = "20") int size,
                                                     @RequestParam(name = "period", required = false) String period,
                                                     @RequestParam(name = "operationType", required = false) String operationType,
                                                     @RequestParam(name = "search", required = false) String search,
                                                     @RequestParam(name = "fromSum", required = false) BigDecimal fromSum,
                                                     @RequestParam(name = "toSum", required = false) BigDecimal toSum) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Order.desc(("sysCreateTime"))));

        switch (period) {
            case "today":
                dateFrom = LocalDate.now();
                dateTo = LocalDate.now();
                break;
            case "week":
                dateFrom = LocalDate.now().minusWeeks(1);
                dateTo = LocalDate.now();
                break;
            case "month":
                dateFrom = LocalDate.now().minusMonths(1);
                dateTo = LocalDate.now();
                break;
            default:
                initionalDate(dateFrom, dateTo);
                break;
        }
        StatementResponse statementOperationsPage = statementOperationService.getSt(account, dateFrom, dateTo, pageable, operationType, fromSum, toSum, search);


        return statementOperationsPage;
    }

    public void initionalDate (LocalDate dateFrom, LocalDate dateTo) {
        if (dateFrom == null) {
            dateFrom = LocalDate.now();
        }
        if (dateTo == null) {
            dateTo = LocalDate.now();
        }
    }






    @GetMapping(value = "/detail", produces = "application/json;charset=UTF-8")
    public OperationDetailsDto getDetail(@RequestParam(value = "operation_id") String operationId) {


        OperationDetailsDto operationDetails = statementOperationService.getOperationDetails(operationId);


        return operationDetails;
    }
}
