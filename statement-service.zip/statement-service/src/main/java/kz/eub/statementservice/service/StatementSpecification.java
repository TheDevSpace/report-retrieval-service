package kz.eub.statementservice.service;

import jakarta.persistence.criteria.*;
import kz.eub.statementservice.model.entity.Statement;
import kz.eub.statementservice.model.entity.StatementOperation;
import org.springframework.data.jpa.domain.Specification;

import java.math.BigDecimal;
import java.time.LocalDate;

public class StatementSpecification {

//    public static Specification<StatementOperation> findByStatementCriteria(String account, LocalDate fromDate, LocalDate toDate, String operationType) {
//        return (Root<StatementOperation> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) -> {
//
//            Subquery<String> subquery = query.subquery(String.class);
//            Root<Statement> subRoot = subquery.from(Statement.class);
//            subquery.select(subRoot.get("id"));
//            Predicate subPredicate1 = criteriaBuilder.equal(subRoot.get("account"), account);
//            Predicate subPredicate2 = criteriaBuilder.between(subRoot.get("fromDate"), fromDate, toDate);
//            subquery.where(criteriaBuilder.and(subPredicate1, subPredicate2));
//
//            Predicate mainPredicate = criteriaBuilder.in(root.get("statementId").get("id")).value(subquery);
//
//            if ("credit".equals(operationType)) {
//                mainPredicate = criteriaBuilder.and(mainPredicate, criteriaBuilder.isNotNull(root.get("credit")));
//            } else if ("debit".equals(operationType)) {
//                mainPredicate = criteriaBuilder.and(mainPredicate, criteriaBuilder.isNotNull(root.get("debet")));
//            }
//
//            return mainPredicate;
//        };
//    }


    public static Specification<StatementOperation> findByStatementCriteria(String account, LocalDate fromDate, LocalDate toDate, String operationType, BigDecimal fromSum, BigDecimal toSum, String search) {
        return (Root<StatementOperation> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) -> {

            Subquery<String> subquery = query.subquery(String.class);
            Root<Statement> subRoot = subquery.from(Statement.class);
            subquery.select(subRoot.get("id"));
            Predicate subPredicate1 = criteriaBuilder.equal(subRoot.get("account"), account);
            Predicate subPredicate2 = criteriaBuilder.between(subRoot.get("fromDate"), fromDate, toDate);
            subquery.where(criteriaBuilder.and(subPredicate1, subPredicate2));

            Predicate mainPredicate = criteriaBuilder.in(root.get("statementId").get("id")).value(subquery);

            if ("credit".equals(operationType)) {
                mainPredicate = criteriaBuilder.and(mainPredicate, criteriaBuilder.isNotNull(root.get("credit")));
            } else if ("debit".equals(operationType)) {
                mainPredicate = criteriaBuilder.and(mainPredicate, criteriaBuilder.isNotNull(root.get("debet")));
            }

            if (fromSum != null && toSum != null) {
                mainPredicate = criteriaBuilder.and(mainPredicate,
                        criteriaBuilder.or(
                                criteriaBuilder.between(root.get("credit"), fromSum, toSum),
                                criteriaBuilder.between(root.get("debet"), fromSum, toSum)
                        )
                );
            }

            Expression<String> searchField = null;
            if (search != null && !search.isEmpty()) {
                if (root.get("credit") != null) {
                    searchField = root.get("benefName");
                } else if (root.get("debet") != null) {
                    searchField = root.get("payer_name");
                }

                if (searchField != null) {
                    String searchPattern = "%" + search + "%";
                    mainPredicate = criteriaBuilder.and(mainPredicate,
                            criteriaBuilder.like(searchField, searchPattern));
                }
            }

            return mainPredicate;
        };
    }

}
