package kz.eub.statementservice.model.dto;

import java.math.BigDecimal;

public record StatementOperationResp(
        String id,
        String docNumber,
        String receiver,
        String currencyCode,
        BigDecimal sum,
        String paymentPurpose,
        String account,
        String operationType

) {}