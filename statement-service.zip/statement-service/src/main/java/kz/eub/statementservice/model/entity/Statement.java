package kz.eub.statementservice.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "sbns_kz_statement")
@Getter
@Setter
public class Statement {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;
    @Column(name = "account")
    private String account;
    @Column(name = "fromdate")
    private LocalDate fromDate;
    @Column(name = "outboundbalance")
    private BigDecimal outboundBalance;

}

