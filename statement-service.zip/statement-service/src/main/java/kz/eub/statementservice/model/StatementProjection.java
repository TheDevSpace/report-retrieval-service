package kz.eub.statementservice.model;

import java.math.BigDecimal;

public interface StatementProjection {

    BigDecimal getOutboundBalance();
    BigDecimal getInBoundBalance();
    BigDecimal getSumCredit();
    BigDecimal getSumDebit();

}
