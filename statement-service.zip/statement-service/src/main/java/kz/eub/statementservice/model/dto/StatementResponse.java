package kz.eub.statementservice.model.dto;


import java.math.BigDecimal;
import java.util.List;

public record StatementResponse(
        BigDecimal outboundBalance,
        BigDecimal inboundBalance,
        BigDecimal sumCredit,
        BigDecimal sumDebit,
        List<StatementOperationResp> payments
) {}
